# Daily-Journal
Your personal e-diary

site link https://daily-journal-web.herokuapp.com

Daily Journal gives you a platform where you can pen down how your day was, your thoughts, actions and lot more on a daily basis. Keeping in mind the privacy of your data, this web application uses the cutting edge technology for authencitation.
When it comes to privacy, Daily Journal gives you a totally secured paltform to keep your data safe.
Being a NodeJS web Application Daily Journal uses Passport authentication for an unobtrusive authencitation.

This website uses cookies for your better browsing experience.
